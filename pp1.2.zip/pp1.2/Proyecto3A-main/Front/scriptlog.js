document.getElementById("boton_registrar").addEventListener("click",registro);
document.getElementById("btn-iniciar").addEventListener("click",iniciarSeccion);
window.addEventListener("resize", agrandar);

//para que se muevan de lado a lado
var contenedor = document.querySelector(".conten_login-registro");
var formularioLog = document.querySelector(".formulario__login");
var formularioregis = document.querySelector(".formulario__registrar");
var CajaTraseraLog= document.querySelector(".caja-login");
var CajaTraseraRegist = document.querySelector(".caja__registrar");



function agrandar(){
    if(window.innerWidth >850){
        CajaTraseraLog.style.display = "block";
        CajaTraseraRegist.style.display= "block";

    }else{
        CajaTraseraRegist.style.display ="block";
        CajaTraseraRegist.style.opacity = "1";
        CajaTraseraLog.style.display = "none";
        CajaTraseraLog.style.display  ="block";
        formularioLog.style.display ="block";
        formularioregis.style.display = "none";
        contenedor.style.left= "0px";
    }
}




function iniciarSeccion(){
if(window.innerWidth >850){
    formularioregis.style.display = "none";
    contenedor.style.left =" 10px";
    formularioLog.style.display = "block";
    CajaTraseraRegist.style.opacity = "1";
    CajaTraseraLog.style.opacity = "0";
}else{
    formularioregis.style.display = "none";
    contenedor.style.left =" 0px";
    formularioLog.style.display = "block";
    CajaTraseraRegist.style.display = "block";
    CajaTraseraLog.style.display = "none";
    }
}

function registro (){
    if(window.innerWidth >850){
    formularioregis.style.display = "block";
    contenedor.style.left =" 410px";
    formularioLog.style.display = "none";
    CajaTraseraRegist.style.opacity = "0";
    CajaTraseraLog.style.opacity = "1";

}else{
    formularioregis.style.display = "block";
    contenedor.style.left =" 0px";
    formularioLog.style.display = "none";
    CajaTraseraRegist.style.display = "none";
    CajaTraseraLog.style.display = "block";
    CajaTraseraLog.style.opacity = "1";

    }
}


// validaciones de los formularios 

const expresiones = {
	usuario: /^[a-zA-Z0-9\_\-]{4,16}$/, // Letras, numeros, guion y guion_bajo
	nombre: /^[a-zA-ZÀ-ÿ\s]{1,40}$/, // Letras y espacios, pueden llevar acentos.
	password: /^.{4,12}$/, // 4 a 12 digitos.
	correo: /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/,
	telefono: /^\d{7,14}$/ // 7 a 14 numeros.
}

const campos = {

    nombre: false,
    apellidoP: false,
    apellidoM: false,
    telefono : false,
    usuario : false,
    correo : false,
    contrasena: false,

}

const validarFormulario = (e) => {

    switch (e.target.name){
        case "nombre":
            validarCampo
    }
}

const validarCampo = (expresiones,input, campo) =>{
    document.getElementById(`grupo__${campo}`).classList.remove('formulario__grupo-incorrecto');
    document.getElementById(`grupo__${campo}`).classList.add('formulario__grupo-correcto');
    document.querySelector(`#grupo__${campo} i`).classList.add('fa-check-circle');
    document.querySelector(`#grupo__${campo} i`).classList.remove('fa-times-circle');
    document.querySelector(`#grupo__${campo} .formulario__input-error`).classList.remove('formulario__input-error-activo');
    campos[campo] = true;
    if(expresion.test(input.value)){

    }else {
		document.getElementById(`grupo__${campo}`).classList.add('formulario__grupo-incorrecto');
		document.getElementById(`grupo__${campo}`).classList.remove('formulario__grupo-correcto');
		document.querySelector(`#grupo__${campo} i`).classList.add('fa-times-circle');
		document.querySelector(`#grupo__${campo} i`).classList.remove('fa-check-circle');
		document.querySelector(`#grupo__${campo} .formulario__input-error`).classList.add('formulario__input-error-activo');
		campos[campo] = false;
	}
}


inputs.forEach((input) => {
	input.addEventListener('keyup', validarFormulario);
	input.addEventListener('blur', validarFormulario);
});




